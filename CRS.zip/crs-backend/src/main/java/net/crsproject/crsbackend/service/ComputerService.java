package net.crsproject.crsbackend.service;

import java.util.List;

import net.crsproject.crsbackend.dto.ComputerDto;

public interface ComputerService {

    ComputerDto createComputer(ComputerDto computerDto);

    ComputerDto getComputerById(Long computerId);

    List<ComputerDto> getAllComputers();

    ComputerDto updateComputer(Long computerId, ComputerDto updatedComputer);

    void deleteComputer(Long computerId);

}
