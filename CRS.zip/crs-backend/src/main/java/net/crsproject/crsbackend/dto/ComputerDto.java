package net.crsproject.crsbackend.dto;

import org.springframework.web.bind.annotation.RestController;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@RestController


public class ComputerDto {
    private Long Id;
    private String Brandname;
    private String Processor;
    private String Issue;
    private String Email;

}
