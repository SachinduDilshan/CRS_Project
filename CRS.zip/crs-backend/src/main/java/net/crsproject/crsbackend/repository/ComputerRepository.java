package net.crsproject.crsbackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import net.crsproject.crsbackend.entity.Computer;

public interface ComputerRepository extends JpaRepository<Computer, Long>{

}
