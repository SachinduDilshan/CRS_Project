package net.crsproject.crsbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrsBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
