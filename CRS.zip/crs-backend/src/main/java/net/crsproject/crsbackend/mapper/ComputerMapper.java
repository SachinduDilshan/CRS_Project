package net.crsproject.crsbackend.mapper;

import net.crsproject.crsbackend.dto.ComputerDto;
import net.crsproject.crsbackend.entity.Computer;

public class ComputerMapper {

    public static ComputerDto maptoComputerDto(Computer computer){
        return new ComputerDto(

        computer.getId(),
        computer.getBrandname(),
        computer.getProcessor(),
        computer.getIssue(),
        computer.getEmail()
        );
    }

    public static Computer maptoComputer(ComputerDto computerDto){

        return new Computer(
            computerDto.getId(),
            computerDto.getBrandname(),
            computerDto.getProcessor(),
            computerDto.getIssue(),
            computerDto.getEmail()

        );
    }

}
