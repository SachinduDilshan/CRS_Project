package net.crsproject.crsbackend.controller;

import java.util.List;

import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import net.crsproject.crsbackend.dto.ComputerDto;
import net.crsproject.crsbackend.service.ComputerService;

@AllArgsConstructor
@CrossOrigin("*")
@RestController
@RequestMapping("/api/computers")
public class ComputerController {

    private ComputerService computerService;

    //Build add computer REST API
    @PostMapping
    public ResponseEntity<ComputerDto> createComputer(@RequestBody ComputerDto computerDto){
        ComputerDto savedComputer= computerService.createComputer(computerDto);
        return new ResponseEntity<>(savedComputer, HttpStatus.CREATED);
    }


    //Build Get Computer REST API
    @GetMapping("{id}")
    public ResponseEntity<ComputerDto> getComputerById(@PathVariable("id") Long computerId){
        ComputerDto computerDto = computerService.getComputerById(computerId);
        return ResponseEntity.ok(computerDto);
    }

    //Build Get All Employees REST API

    @GetMapping
    public ResponseEntity<List<ComputerDto>> getAllComputers(){

        List<ComputerDto> computers = computerService.getAllComputers();
        return ResponseEntity.ok(computers);
    }

    @PutMapping("{id}")
    public ResponseEntity<ComputerDto> updateComputer(@PathVariable("id") Long computerId, @RequestBody ComputerDto updatedComputer){
        ComputerDto computerDto=computerService.updateComputer(computerId, updatedComputer);
        return ResponseEntity.ok(computerDto);
     }


     //delete computer
     @DeleteMapping("{id}")
     public ResponseEntity<String> deleteComputer(@PathVariable("id") Long computerId){
        computerService.deleteComputer(computerId);

        return ResponseEntity.ok("Computer deleted successfulyy. ");
     }

   

}
