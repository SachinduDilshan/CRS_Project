import React from 'react'

const FooterComp = () => {
  return (
    <div>
        <footer className='footer'>
            <span>
                All rights reserved 2024 by K.G.S.D. Abeyrathne
                <br>
                
                </br>
                SA22527974-PPA Individual Assignment
            </span>

        </footer>
    </div>
  )
}

export default FooterComp