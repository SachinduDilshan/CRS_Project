package net.crsproject.crsbackend.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;


import net.crsproject.crsbackend.dto.ComputerDto;
import net.crsproject.crsbackend.entity.Computer;
import net.crsproject.crsbackend.exception.ResourceNofDoundException;
import net.crsproject.crsbackend.mapper.ComputerMapper;
import net.crsproject.crsbackend.repository.ComputerRepository;
import net.crsproject.crsbackend.service.ComputerService;


@Service
public class ComputerServiceImpl implements ComputerService{

    @Override
    public ComputerDto updateComputer(Long computerId, ComputerDto updatedComputer) {
        
        Computer computer=computerRepository.findById(computerId).orElseThrow(() -> new ResourceNofDoundException("That Computer is no exist with given ID : "+computerId)
        );

        computer.setBrandname(updatedComputer.getBrandname());
        computer.setProcessor(updatedComputer.getProcessor());
        computer.setIssue(updatedComputer.getIssue());
        computer.setEmail(updatedComputer.getEmail());

        Computer updatedComputerObj= computerRepository.save(computer);

        return ComputerMapper.maptoComputerDto(updatedComputerObj);
    }

    private ComputerRepository computerRepository;

    @Override
    public ComputerDto createComputer(ComputerDto computerDto) {

        Computer computer = ComputerMapper.maptoComputer(computerDto);
        Computer savedComputer = computerRepository.save(computer);

        return ComputerMapper.maptoComputerDto(savedComputer);
    }

    @Override
    public ComputerDto getComputerById(Long computerId) {

        Computer computer = computerRepository.findById(computerId)
        .orElseThrow(() ->
                    new ResourceNofDoundException("That Computer is no exist with given ID : "+computerId));
        

        return ComputerMapper.maptoComputerDto(computer);
    }

    @Override
    public List<ComputerDto> getAllComputers() {
        
        List<Computer> computers= computerRepository.findAll();
        return computers.stream().map((computer) -> ComputerMapper.maptoComputerDto(computer)).collect(Collectors.toList());
     }

    @Override
    public void deleteComputer(Long computerId) {
        Computer computer= computerRepository.findById(computerId).orElseThrow(() -> new ResourceNofDoundException("That Computer is no exist with given ID : "+computerId)
        
        );

        computerRepository.deleteById(computerId);
    }


}
