import React, {useEffect, useState} from 'react'
import { deleteComputer, listComputers } from '../services/ComputerService'
import { useNavigate } from 'react-router-dom'

const ListComputerComponent = () => {
    
    const navigator = useNavigate();

    /*const [computer, setComputer] = useState([])

    useEffect(() => {
        listComputers().then((response) => {
            setComputer(response.data);

        }).catch(error => {
            console.error(error);
        })
    }, [])*/

    function getAllComputers() {
        listComputers().then((response) => {
            setComputer(response.data);

        }).catch(error => {
            console.error(error);
        })
    }

    const dummyData= [
        {
            "id": 1,
            "brandname": "Asus",
            "processor": "11th Gen Intel(R) Core(TM) i5-1135G7 @ 2.40GHz   2.42 GHz" ,
            "issue":"Display flickering",
            "email": "sd@gmail.com"
        },
        {
            "id": 2,
            "brandname": "HP",
            "processor": "10th Gen Intel(R) Core(TM) i7-1135G7 @ 2.40GHz 2.42 GHz" ,
            "issue":"Blue Screen of Death (BSOD)",
            "email": "bla@gmail.com"
        },
        {
            "id": 3,
            "brandname": "DELL",
            "processor": "7th Gen Intel(R) Core(TM) i3" ,
            "issue":"Slow Performance",
            "email": "sd@gmail.com"
        },
        {
            "id": 4,
            "brandname": "Lenovo",
            "processor": "8th Gen Intel(R) Core(TM) i5" ,
            "issue":"Overheating",
            "email": "sd@gmail.com"
        }
    ]
    
    function addnewComputer(){
        navigator('/add-computer')
    }

    function updateComputer(id){
        navigator(`/edit-computer/${id}`)
    }

    function removeComputer(id) {
        console.log(id);

        deleteComputer(id).then((response) => {
            getAllComputers()

        }).catch(error => {
            console.error(error);
        })
    }


  return (
    <div className='container'>
        <h2 className='text-center'>List of Computers to Repair</h2>
        <button className='btn btn-primary mb-2' onClick={addnewComputer}>Add Computer to Repair</button>
        <table className='table table-striped table-bordered'>
            <thead>
                <tr>
                    <th>ID of the Computer</th>
                    <th>Brandname of the Computer</th>
                    <th>Processor of the Computer</th>
                    <th>Issue of the Computer</th>
                    <th>Email of the customer</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                {
                    dummyData.map(computer => 
                    <tr key={computer.id}>
                        <td>{computer.id}</td>
                        <td>{computer.brandname}</td>
                        <td>{computer.processor}</td>
                        <td>{computer.issue}</td>
                        <td>{computer.email}</td>
                        <td>
                            <button className='btn btn-info' onClick={() => updateComputer(computer.id)}>Update</button>
                            <button className='btn btn-danger' onClick={() => removeComputer(computer.id)} style={{marginTop: '10px'}}>Delete</button>
                        </td>
                    </tr>)
                }
                <tr>
                    
                </tr>
            </tbody>
        </table>
    </div>
  )
}

export default ListComputerComponent