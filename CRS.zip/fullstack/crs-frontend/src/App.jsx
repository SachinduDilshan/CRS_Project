import './App.css'
import ComputerCompo from './Components/ComputerCompo'
import FooterComp from './Components/FooterComp'
import HeaderCompo from './Components/HeaderCompo'
import ListComputerComponent from './Components/ListComputerComponent'
import {BrowserRouter, Route, Routes} from 'react-router-dom'

function App() {


  return (
    <>
    <BrowserRouter>
      <HeaderCompo />
      <Routes>
        <Route path='/' element = { <ListComputerComponent />}></Route>
        <Route path='/computers' element = { <ListComputerComponent/>}></Route>
        <Route path='/add-computer' element = { <ComputerCompo/>}></Route>
        <Route path ='/edit-computer/:id' element= {<ComputerCompo/>}></Route>
      </Routes>
      <FooterComp />
    </BrowserRouter>
      
    </>
  )
}

export default App
