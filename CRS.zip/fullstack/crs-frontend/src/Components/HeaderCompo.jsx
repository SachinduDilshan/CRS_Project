import React from 'react'

const HeaderCompo = () => {
  return (
    <div>
        <header>
            <nav className='navbar navbar-dark bg-dark'>
            <a className="navbar-brand" href="#">Computer Item Repairing System</a>
            </nav>
        </header>
    </div>
  )
}

export default HeaderCompo