import React, { useEffect, useState } from 'react'
import { createComputer, getComputer, updateComputer } from '../services/ComputerService'
import { useNavigate, useParams,  } from 'react-router-dom'

const ComputerCompo = () => {

    const [brandname, setBrandName] = useState('')
    const [processor, setProcessor] = useState('')
    const [issue, setIssue] = useState('')
    const [email, setEmail] = useState('')

    const {id} =useParams();

    const [errors, setErrors] = useState({
        brandname:'',
        processor:'',
        issue:'',
        email:''
    })

    const navigator= useNavigate();

   /* useEffect(() => {
        if(id){
            getComputer(id).then((response) =>{
                setBrandName(response.data.brandname);
                setProcessor(response.data.processor);
                setIssue(response.data.issue);
                setEmail(response.data.email);
            }).catch(error => {
                console.error(error);
            })
        }

    }, [id]
)*/


    function saveorUpdateComputer(e){
        e.preventDefault();

        if(validateForm()){

            
        const computer= {brandname, processor, issue, email}
        console.log(computer)

        if(id){
            updateComputer(id, com).then((response) =>{
                console.log(response.data);
                navigator('/computers');
            }).catch(error => {
                console.error(error);
            })
        } else{
            createComputer(computer).then((response) => {
                console.log(response.data);
                navigator('/computers')
            }).catch(error => {
                console.error(error)
            })
        }

        createComputer(computer).then((response) => {
            console.log(response.data);
            navigator('/computers')
        })
        }

        
    }


    function validateForm() {
        let valid = true;

        const errorCopy = {... errors}

        if(brandname.trim()){
            errorCopy.brandname='';
        } else {
            errorCopy.brandname='Brandname is empty';
            valid=false;
        }
        if(processor.trim()){
            errorCopy.processor='';
        } else {
            errorCopy.processor='Processor detail is empty';
            valid=false;
        }
        if(issue.trim()){
            errorCopy.issue='';
        } else {
            errorCopy.issue='Issue detail is empty';
            valid=false;
        }
        if(email.trim()){
            errorCopy.email='';
        } else {
            errorCopy.email='Email field is empty';
            valid=false;
        }

        setErrors(errorCopy);

        return valid;
    }

    function pageTitle(){
        if(id) {
            return <h2 className='text-center'>Update Computer Item</h2>
        } else{
            return <h2 className='text-center'>Add Computer Item</h2>
        }

    }

  return (
    <div className='container'>
        <br/> <br/>
        <div className='row'>
            <div className='card col-md-6 offset-md-3 offset-md-3'>
                {
                    pageTitle()
                }
                
                <div className='card-body'>
                    <form>
                        <div className='form-group mb-2'>
                            <label className='form-label'>Brand Name of the Item</label>
                            <input
                                type='text'
                                placeholder='Enter brandname of the item'
                                name='brandname'
                                value={brandname}
                                className={`form-control ${ errors.brandname ? 'is-invalid': '' }`}
                                onChange={(e) => setBrandName(e.target.value)}
                            >
                            </input>
                            { errors.brandname && <div className='invalid-feedback'>{errors.brandname} </div>}
                        </div>

                        <div className='form-group mb-2'>
                            <label className='form-label'>Processor of the Computer</label>
                            <input
                                type='text'
                                placeholder='Enter processor of the computer'
                                name='processor'
                                value={processor}
                                className={`form-control ${ errors.processor ? 'is-invalid': '' }`}
                                onChange={(e) => setProcessor(e.target.value)}
                            >
                            </input>
                            { errors.processor && <div className='invalid-feedback'>{errors.processor} </div>}
                        </div>

                        <div className='form-group mb-2'>
                            <label className='form-label'>Issue of the Item</label>
                            <input
                                type='text'
                                placeholder='Enter issue of the item'
                                name='issue'
                                value={issue}
                                className={`form-control ${ errors.issue ? 'is-invalid': '' }`}
                                onChange={(e) => setIssue(e.target.value)}
                            >
                            </input>
                            { errors.issue && <div className='invalid-feedback'>{errors.issue} </div>}
                        </div>

                        <div className='form-group mb-2'>
                            <label className='form-label'>Email</label>
                            <input
                                type='email'
                                placeholder='Enter email of the customer'
                                name='email'
                                value={email}
                                className={`form-control ${ errors.email ? 'is-invalid': '' }`}
                                onChange={(e) => setEmail(e.target.value)}
                            >
                            </input>
                            { errors.email && <div className='invalid-feedback'>{errors.email} </div>}
                        </div>

                        <button className='btn btn-success' onClick={saveorUpdateComputer}>Submit</button>
                    </form>
                </div>
            </div>
        </div>

    </div>
  )
}

export default ComputerCompo